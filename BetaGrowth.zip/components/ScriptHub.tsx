
import React, { useState, useEffect } from 'react';
import { db } from '../services/dbService';
import { gemini } from '../services/geminiService';
import { ScriptData, ScriptVariation } from '../types';

const ScriptHub: React.FC = () => {
  const [data, setData] = useState<ScriptData>(db.getScripts());
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    db.saveScripts(data);
  }, [data]);

  const handleGenerate = async () => {
    if (!data.baseIdea) return;
    setIsGenerating(true);
    const variations = await gemini.generateScripts(data.baseIdea);
    if (variations.length > 0) {
      setData({ ...data, variations: variations.map((v: any) => ({ ...v, id: Math.random().toString() })) });
    }
    setIsGenerating(false);
  };

  return (
    <div className="px-6 pt-6 animate-in fade-in duration-500">
      <header className="pb-8 flex justify-between items-start">
        <div className="space-y-1">
          <p className="text-[10px] font-medium text-zinc-500 uppercase tracking-[0.3em]">Estudio</p>
          <h1 className="text-2xl font-light tracking-tight"><span className="premium-serif italic">Multiplicador</span> de Contenido</h1>
        </div>
        <button 
          onClick={handleGenerate}
          disabled={isGenerating || !data.baseIdea}
          className="size-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white transition-colors disabled:opacity-50"
        >
          <span className={`material-symbols-outlined text-xl ${isGenerating ? 'animate-spin' : ''}`}>
            {isGenerating ? 'sync' : 'bolt'}
          </span>
        </button>
      </header>

      <section className="bg-zinc-900/40 border border-zinc-800/60 rounded-2xl p-6 mb-8">
        <div className="flex items-center gap-2 mb-3">
          <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Idea Central</span>
          <div className="h-[1px] flex-1 bg-zinc-800"></div>
        </div>
        <textarea 
          value={data.baseIdea}
          onChange={(e) => setData({ ...data, baseIdea: e.target.value })}
          className="w-full bg-transparent border-none p-0 text-xl font-light leading-snug focus:ring-0 text-white placeholder:text-zinc-700 resize-none h-24"
          placeholder="Escribe el concepto central aquí... Ej. Por qué el escalamiento lineal mata tu consultora."
        />
      </section>

      <section className="space-y-6 pb-20">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-semibold text-zinc-500 uppercase tracking-[0.2em]">Ángulos de Guion</h3>
          <span className="text-[10px] text-zinc-600">{data.variations.length} Variaciones Generadas</span>
        </div>

        {isGenerating && (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="bg-card-dark/50 border border-zinc-800/80 rounded-2xl p-6 h-48 animate-pulse"></div>
            ))}
          </div>
        )}

        <div className="space-y-4">
          {data.variations.map((v, i) => (
            <article key={v.id} className="bg-card-dark border border-zinc-800/80 rounded-2xl p-6 space-y-4 group">
              <div className="flex justify-between items-center">
                <span className="px-2 py-1 bg-zinc-800 rounded text-[9px] font-bold text-zinc-400 uppercase tracking-tighter">Ángulo {i + 1}</span>
                <h4 className="text-xs font-medium text-zinc-500 group-hover:text-primary transition-colors">{v.angle}</h4>
              </div>
              <div className="space-y-4">
                <div className="bg-black/20 p-3 rounded-lg border-l-2 border-primary">
                  <p className="text-[9px] font-bold text-primary uppercase mb-1 tracking-widest">Gancho</p>
                  <p className="text-sm font-light text-zinc-300 italic">{v.hook}</p>
                </div>
                <div className="p-1">
                  <p className="text-[9px] font-bold text-zinc-500 uppercase mb-1 tracking-widest">Valor</p>
                  <p className="text-xs text-zinc-400 font-light leading-relaxed">{v.value}</p>
                </div>
                <div className="p-1">
                  <p className="text-[9px] font-bold text-zinc-500 uppercase mb-1 tracking-widest">Llamada a la Acción (CTA)</p>
                  <p className="text-xs text-zinc-400 font-light italic">{v.cta}</p>
                </div>
              </div>
              <div className="flex justify-between items-center pt-2 border-t border-zinc-800/50">
                <button 
                  onClick={() => navigator.clipboard.writeText(`${v.hook}\n\n${v.value}\n\n${v.cta}`)}
                  className="text-[10px] font-medium text-zinc-500 hover:text-white flex items-center gap-1 uppercase tracking-widest transition-colors"
                >
                  <span className="material-symbols-outlined text-sm">content_copy</span> Copiar Guion
                </button>
                <div className="flex gap-2">
                   <button className="size-8 rounded-full bg-zinc-800 text-zinc-400 flex items-center justify-center hover:text-white transition-colors">
                    <span className="material-symbols-outlined text-sm">ios_share</span>
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </div>
  );
};

export default ScriptHub;
