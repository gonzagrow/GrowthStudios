
import React, { useState, useEffect } from 'react';
import { db } from '../services/dbService';
import { gemini } from '../services/geminiService';
import { OfferData, OfferItem } from '../types';

const OfferBuilder: React.FC = () => {
  const [data, setData] = useState<OfferData>(db.getOffer());
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    db.saveOffer(data);
  }, [data]);

  const addComponent = () => {
    const newItem: OfferItem = {
      id: Date.now().toString(),
      name: "Nuevo Componente",
      description: "Detalles del beneficio",
      value: 1000
    };
    setData({ ...data, stack: [...data.stack, newItem] });
  };

  const removeComponent = (id: string) => {
    setData({ ...data, stack: data.stack.filter(i => i.id !== id) });
  };

  const handleOptimize = async () => {
    if (!data.promise && data.stack.length === 0) return;
    setIsOptimizing(true);
    const optimized = await gemini.optimizeOffer(data.promise, data.stack);
    if (optimized) {
      setData({
        ...data,
        promise: optimized.promise,
        stack: optimized.stack.map((s: any) => ({ ...s, id: Math.random().toString() })),
        lastUpdated: new Date().toISOString()
      });
    }
    setIsOptimizing(false);
  };

  const totalValue = data.stack.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div className="px-6 pt-6 animate-in slide-in-from-right duration-500 pb-48">
      <header className="mb-10 text-center">
        <p className="text-[10px] font-medium text-zinc-500 uppercase tracking-[0.3em] mb-2">Arquitecto de</p>
        <h2 className="text-white text-3xl font-extrabold tracking-tight">Oferta <span className="premium-serif italic">Irresistible</span></h2>
        <p className="text-slate-500 text-sm mt-2">Diseña la base de tu conversión de alto valor.</p>
      </header>

      <section className="mb-10 relative">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-accent text-xl">auto_awesome</span>
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">La Gran Promesa</label>
          </div>
          <button 
            onClick={handleOptimize}
            disabled={isOptimizing}
            className="text-[10px] font-bold text-primary flex items-center gap-1 hover:brightness-125 transition-all uppercase tracking-widest disabled:opacity-50"
          >
            <span className={`material-symbols-outlined text-sm ${isOptimizing ? 'animate-spin' : ''}`}>
              {isOptimizing ? 'sync' : 'magic_button'}
            </span>
            {isOptimizing ? 'Optimizando...' : 'Optimizar con IA'}
          </button>
        </div>
        <div className="relative group">
          <textarea 
            value={data.promise}
            onChange={(e) => setData({ ...data, promise: e.target.value })}
            className="w-full bg-card-dark border border-border-dark rounded-2xl p-5 text-base text-white placeholder:text-slate-600 focus:border-accent focus:ring-1 focus:ring-accent transition-all duration-300 min-h-[140px] resize-none leading-relaxed" 
            placeholder="En 90 días, te ayudaremos a [Resultado X] mediante [Método Y] sin [Punto de Dolor Z]..."
          ></textarea>
          <div className="absolute bottom-4 right-4 text-[10px] text-zinc-600 font-mono">
            {data.promise.length} CARACTERES
          </div>
        </div>
      </section>

      <section className="space-y-4 mb-10">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-accent text-xl">layers</span>
            <label className="text-[10px] font-bold uppercase tracking-[0.2em] text-slate-400">Stack de Valor</label>
          </div>
          <button 
            onClick={addComponent}
            className="text-accent text-[10px] font-bold flex items-center gap-1 hover:opacity-80 uppercase tracking-widest"
          >
            <span className="material-symbols-outlined text-sm">add_circle</span>
            Añadir
          </button>
        </div>

        <div className="space-y-3">
          {data.stack.map((item) => (
            <div key={item.id} className="group flex items-center gap-4 bg-card-dark border border-border-dark p-4 rounded-xl hover:border-zinc-700 transition-colors">
              <div className="size-10 rounded-lg bg-zinc-800 flex items-center justify-center text-accent shrink-0">
                <span className="material-symbols-outlined text-xl">
                  {item.name.toLowerCase().includes('mentoría') ? 'groups' : item.name.toLowerCase().includes('comunidad') ? 'forum' : 'inventory_2'}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <input 
                  value={item.name}
                  onChange={(e) => {
                    const newStack = data.stack.map(i => i.id === item.id ? { ...i, name: e.target.value } : i);
                    setData({ ...data, stack: newStack });
                  }}
                  placeholder="Nombre del componente"
                  className="bg-transparent border-none p-0 text-sm font-semibold text-white focus:ring-0 w-full placeholder:text-zinc-700"
                />
                <input 
                  value={item.description}
                  onChange={(e) => {
                    const newStack = data.stack.map(i => i.id === item.id ? { ...i, description: e.target.value } : i);
                    setData({ ...data, stack: newStack });
                  }}
                  placeholder="Descripción rápida"
                  className="bg-transparent border-none p-0 text-xs text-slate-500 focus:ring-0 w-full placeholder:text-zinc-800"
                />
              </div>
              <div className="flex flex-col items-end gap-1">
                <div className="flex items-center">
                  <span className="text-zinc-600 text-[10px] mr-1">$</span>
                  <input 
                    type="number"
                    value={item.value}
                    onChange={(e) => {
                      const newStack = data.stack.map(i => i.id === item.id ? { ...i, value: parseInt(e.target.value) || 0 } : i);
                      setData({ ...data, stack: newStack });
                    }}
                    className="bg-transparent border-none p-0 text-zinc-500 font-mono text-sm focus:ring-0 w-16 text-right"
                  />
                </div>
                <button onClick={() => removeComponent(item.id)} className="opacity-0 group-hover:opacity-100 transition-opacity">
                  <span className="material-symbols-outlined text-xs text-red-900">delete</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-zinc-900/40 border border-zinc-800/50 rounded-2xl p-6 space-y-6">
        <div className="flex justify-between items-center pb-4 border-b border-zinc-800/50">
          <div className="space-y-1">
            <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Valor Real del Stack</p>
            <p className="text-xl font-light text-zinc-400 font-mono line-through opacity-50">${totalValue.toLocaleString()}</p>
          </div>
          <div className="text-right space-y-1">
            <p className="text-[10px] font-bold text-accent uppercase tracking-widest">Precio de la Oferta</p>
            <div className="flex items-center justify-end">
              <span className="text-accent text-lg mr-1">$</span>
              <input 
                type="number"
                value={data.price}
                onChange={(e) => setData({ ...data, price: parseInt(e.target.value) || 0 })}
                className="bg-transparent border-none p-0 text-3xl font-extrabold text-white font-mono focus:ring-0 w-32 text-right"
              />
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="size-2 rounded-full bg-green-500 shadow-lg shadow-green-500/20"></span>
            <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Descuento Percibido</p>
          </div>
          <p className="text-sm font-bold text-green-500">
            {totalValue > 0 ? Math.round(((totalValue - data.price) / totalValue) * 100) : 0}% OFF
          </p>
        </div>
      </section>

      <div className="fixed bottom-24 left-0 w-full px-6 flex justify-center z-40 max-w-md mx-auto">
        <button className="w-full bg-white hover:bg-zinc-200 text-black font-extrabold py-4 rounded-2xl shadow-2xl shadow-white/10 flex items-center justify-center gap-3 active:scale-[0.97] transition-all uppercase tracking-[0.2em] text-xs">
          Finalizar Oferta
          <span className="material-symbols-outlined font-bold">check_circle</span>
        </button>
      </div>
    </div>
  );
};

export default OfferBuilder;
