
import React, { useState } from 'react';

interface LoginViewProps {
  onLogin: (name: string, email: string) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name && email) onLogin(name, email);
  };

  return (
    <div className="min-h-screen flex flex-col justify-center px-8 bg-bg-dark max-w-md mx-auto">
      <div className="mb-12">
        <p className="text-[10px] font-medium text-zinc-500 uppercase tracking-[0.3em] mb-2">Bienvenido a</p>
        <h1 className="text-4xl font-light tracking-tight">Impulso <span className="premium-serif italic">Studio</span></h1>
        <p className="mt-4 text-zinc-400 font-light">Diseña tu estrategia de crecimiento impulsada por IA.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Nombre Completo</label>
          <input 
            type="text" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-card-dark border border-border-dark rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-primary focus:border-primary"
            placeholder="Ej. Juan Pérez"
            required
          />
        </div>
        <div>
          <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Correo Electrónico</label>
          <input 
            type="email" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-card-dark border border-border-dark rounded-xl px-4 py-3 text-white focus:ring-1 focus:ring-primary focus:border-primary"
            placeholder="juan@empresa.com"
            required
          />
        </div>
        <button 
          type="submit"
          className="w-full bg-white text-black font-bold py-4 rounded-xl hover:bg-zinc-200 transition-colors flex items-center justify-center gap-2 group"
        >
          Comenzar
          <span className="material-symbols-outlined group-hover:translate-x-1 transition-transform">arrow_forward</span>
        </button>
      </form>
    </div>
  );
};

export default LoginView;
