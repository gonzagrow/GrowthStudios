
import React from 'react';
import { User } from '../types';

interface ProfileViewProps {
  user: User;
  onLogout: () => void;
}

const ProfileView: React.FC<ProfileViewProps> = ({ user, onLogout }) => {
  return (
    <div className="px-8 pt-12 animate-in fade-in duration-500">
      <div className="flex flex-col items-center text-center mb-12">
        <div className="size-24 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-4 overflow-hidden">
          <img src={`https://picsum.photos/seed/${user.email}/150/150`} alt="Avatar" className="w-full h-full object-cover opacity-80" />
        </div>
        <h2 className="text-2xl font-light tracking-tight">{user.name}</h2>
        <p className="text-zinc-500 text-sm mt-1">{user.email}</p>
        <span className="mt-4 px-3 py-1 bg-primary/10 text-primary text-[10px] font-bold uppercase tracking-widest rounded-full border border-primary/20">Plan Growth Pro</span>
      </div>

      <div className="space-y-4">
        <button className="w-full bg-card-dark border border-border-dark p-4 rounded-xl flex items-center justify-between group">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-zinc-500 group-hover:text-white transition-colors">settings</span>
            <span className="text-sm font-medium">Configuración de Cuenta</span>
          </div>
          <span className="material-symbols-outlined text-zinc-700">chevron_right</span>
        </button>
        <button className="w-full bg-card-dark border border-border-dark p-4 rounded-xl flex items-center justify-between group">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-zinc-500 group-hover:text-white transition-colors">notifications</span>
            <span className="text-sm font-medium">Notificaciones</span>
          </div>
          <span className="material-symbols-outlined text-zinc-700">chevron_right</span>
        </button>
        <button className="w-full bg-card-dark border border-border-dark p-4 rounded-xl flex items-center justify-between group">
          <div className="flex items-center gap-3">
            <span className="material-symbols-outlined text-zinc-500 group-hover:text-white transition-colors">help_center</span>
            <span className="text-sm font-medium">Soporte y Ayuda</span>
          </div>
          <span className="material-symbols-outlined text-zinc-700">chevron_right</span>
        </button>
        
        <div className="pt-8">
          <button 
            onClick={onLogout}
            className="w-full border border-red-900/30 text-red-500 p-4 rounded-xl flex items-center justify-center gap-2 hover:bg-red-500/10 transition-colors text-sm font-bold uppercase tracking-widest"
          >
            <span className="material-symbols-outlined">logout</span>
            Cerrar Sesión
          </button>
        </div>
      </div>
      
      <p className="mt-20 text-center text-[10px] text-zinc-700 font-bold uppercase tracking-widest">Versión 2.1.0 Beta</p>
    </div>
  );
};

export default ProfileView;
