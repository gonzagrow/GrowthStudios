
import React, { useState, useEffect } from 'react';
import { db } from '../services/dbService';
import { gemini } from '../services/geminiService';
import { FunnelData } from '../types';

const FunnelView: React.FC = () => {
  const [data, setData] = useState<FunnelData>(db.getFunnel());
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    db.saveFunnel(data);
  }, [data]);

  const runAnalysis = async () => {
    setIsAnalyzing(true);
    const result = await gemini.analyzeFunnel(data.tofu, data.mofu, data.bofu);
    if (result) {
      setData({
        ...data,
        priorityText: result.priorityText,
        prioritySubtext: result.prioritySubtext,
        lastUpdated: new Date().toISOString()
      });
    }
    setIsAnalyzing(false);
  };

  const handleValueChange = (key: 'tofu' | 'mofu' | 'bofu', val: number) => {
    setData({ ...data, [key]: val });
  };

  const ProgressRing: React.FC<{ value: number, label: string, sub: string }> = ({ value, label, sub }) => (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative size-20 flex items-center justify-center">
        <svg className="radial-progress size-20">
          <circle className="text-zinc-900" cx="40" cy="40" fill="transparent" r="36" stroke="currentColor" strokeWidth="2"></circle>
          <circle 
            className="text-white transition-all duration-1000 ease-out" 
            cx="40" cy="40" fill="transparent" r="36" stroke="currentColor" strokeWidth="2"
            strokeDasharray="226.2" 
            strokeDashoffset={226.2 - (226.2 * value) / 100} 
            strokeLinecap="round"
          ></circle>
        </svg>
        <span className="absolute text-[10px] font-semibold tracking-widest text-zinc-400">{value}%</span>
      </div>
      <div className="text-center">
        <p className="text-[10px] font-bold text-zinc-500 tracking-widest uppercase">{label}</p>
        <p className="text-[9px] text-zinc-600 mt-1">{sub}</p>
      </div>
      <input 
        type="range" min="0" max="100" value={value} 
        onChange={(e) => handleValueChange(label.toLowerCase() as any, parseInt(e.target.value))}
        className="w-16 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-white"
      />
    </div>
  );

  return (
    <div className="px-8 pt-6 animate-in fade-in duration-500">
      <header className="pb-12 flex justify-between items-end">
        <div className="space-y-1">
          <p className="text-[10px] font-medium text-zinc-500 uppercase tracking-[0.3em]">Panel de</p>
          <h1 className="text-3xl font-light tracking-tight">Embudo de <span className="premium-serif italic">Crecimiento</span></h1>
        </div>
        <button 
          onClick={runAnalysis}
          disabled={isAnalyzing}
          className="size-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white transition-colors disabled:opacity-50"
        >
          <span className={`material-symbols-outlined text-xl ${isAnalyzing ? 'animate-spin' : ''}`}>
            {isAnalyzing ? 'sync' : 'auto_awesome'}
          </span>
        </button>
      </header>

      <section className="flex justify-between items-start py-4">
        <ProgressRing value={data.tofu} label="TOFu" sub="Atraer" />
        <ProgressRing value={data.mofu} label="MOFu" sub="Nutrir" />
        <ProgressRing value={data.bofu} label="BOFu" sub="Convertir" />
      </section>

      <section className="pt-12">
        <div className="flex items-center gap-2 mb-6">
          <div className="h-[1px] w-4 bg-zinc-700"></div>
          <h2 className="text-[11px] font-semibold text-zinc-500 uppercase tracking-[0.2em]">Prioridad de Crecimiento</h2>
        </div>
        <div className="bg-card-dark border border-zinc-800/50 rounded-2xl p-8 space-y-6 relative overflow-hidden group">
          {isAnalyzing && (
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-10">
              <p className="text-xs font-bold tracking-widest uppercase animate-pulse">Analizando Embudo...</p>
            </div>
          )}
          <div className="space-y-4">
            <h3 className="text-2xl font-light leading-snug">
              {data.priorityText.split(' ').map((word, i) => 
                word.toLowerCase() === 'gancho' || word.toLowerCase() === 'valor' || word.toLowerCase() === 'irresistible' 
                  ? <span key={i} className="premium-serif italic mr-1">{word} </span> 
                  : <span key={i}>{word} </span>
              )}
            </h3>
            <p className="text-sm text-zinc-400 font-light leading-relaxed">
              {data.prioritySubtext}
            </p>
          </div>
          <div className="pt-4 flex items-center justify-between border-t border-zinc-800/50">
            <div className="flex items-center gap-2">
              <span className="size-2 rounded-full bg-blue-500 animate-pulse"></span>
              <span className="text-[10px] font-medium text-zinc-500 uppercase tracking-widest">Enfoque Activo</span>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FunnelView;
