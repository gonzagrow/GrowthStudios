
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const gemini = {
  analyzeFunnel: async (tofu: number, mofu: number, bofu: number) => {
    const prompt = `Analiza un embudo de ventas con estas métricas: TOFU ${tofu}%, MOFU ${mofu}%, BOFU ${bofu}%. 
    Identifica el mayor cuello de botella y sugiere una "Prioridad de Crecimiento" estratégica en español.
    Responde en formato JSON con dos campos: "priorityText" (una frase corta e impactante) y "prioritySubtext" (una explicación de 2 frases).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            priorityText: { type: Type.STRING },
            prioritySubtext: { type: Type.STRING }
          },
          required: ["priorityText", "prioritySubtext"]
        }
      }
    });

    try {
      return JSON.parse(response.text);
    } catch (e) {
      return null;
    }
  },

  generateScripts: async (baseIdea: string) => {
    const prompt = `Como un experto estratega de contenido, toma esta idea central: "${baseIdea}".
    Genera 3 variaciones de guiones para redes sociales con diferentes ángulos: 
    1. Cazador de Mitos (desafía una creencia común).
    2. Paso a Paso (metodología clara).
    3. Prueba de Resultados (narrativa basada en éxito).
    
    Responde en formato JSON con un array de objetos "variations", cada uno con: angle, title, hook, value, cta. Todo en español.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            variations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  angle: { type: Type.STRING },
                  title: { type: Type.STRING },
                  hook: { type: Type.STRING },
                  value: { type: Type.STRING },
                  cta: { type: Type.STRING }
                },
                required: ["angle", "title", "hook", "value", "cta"]
              }
            }
          }
        }
      }
    });

    try {
      return JSON.parse(response.text).variations;
    } catch (e) {
      return [];
    }
  },

  optimizeOffer: async (promise: string, stack: any[]) => {
    const prompt = `Eres un experto en "Offer Architecture" estilo Alex Hormozi. 
    Toma esta oferta actual y elévala al siguiente nivel. Hazla absolutamente irresistible, eliminando el riesgo y aumentando el valor percibido.
    
    Promesa actual: "${promise}"
    Componentes actuales: ${JSON.stringify(stack)}

    Responde en JSON con una versión mejorada de la "promise" y el "stack" (mejorando nombres y descripciones de componentes para que suenen más valiosos).
    Mantén el idioma en español.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            promise: { type: Type.STRING, description: "La nueva promesa ultra-irresistible." },
            stack: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  value: { type: Type.NUMBER }
                }
              }
            }
          },
          required: ["promise", "stack"]
        }
      }
    });

    try {
      return JSON.parse(response.text);
    } catch (e) {
      return null;
    }
  }
};
