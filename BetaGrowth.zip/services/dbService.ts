
import { User, FunnelData, OfferData, ScriptData } from '../types';

const STORAGE_KEYS = {
  USER: 'impulso_user',
  FUNNEL: 'impulso_funnel',
  OFFER: 'impulso_offer',
  SCRIPTS: 'impulso_scripts'
};

export const db = {
  // User Operations
  getUser: (): User | null => {
    const data = localStorage.getItem(STORAGE_KEYS.USER);
    return data ? JSON.parse(data) : null;
  },
  setUser: (user: User) => {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  },
  logout: () => {
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  // Funnel Operations
  getFunnel: (): FunnelData => {
    const data = localStorage.getItem(STORAGE_KEYS.FUNNEL);
    return data ? JSON.parse(data) : {
      tofu: 70,
      mofu: 45,
      bofu: 20,
      priorityText: "Refina el Gancho de Valor para el dolor operativo actual de tu ICP.",
      prioritySubtext: "Los datos muestran una caída en la etapa de Confianza (MOFu). Tu perfil de cliente ideal busca claridad en la escalabilidad.",
      lastUpdated: new Date().toISOString()
    };
  },
  saveFunnel: (data: FunnelData) => {
    localStorage.setItem(STORAGE_KEYS.FUNNEL, JSON.stringify(data));
  },

  // Offer Operations
  getOffer: (): OfferData => {
    const data = localStorage.getItem(STORAGE_KEYS.OFFER);
    return data ? JSON.parse(data) : {
      promise: "",
      stack: [
        { id: '1', name: "Currículum y Recursos", description: "Módulos de transformación core", value: 2500 },
        { id: '2', name: "Mentoría Semanal", description: "Sesiones grupales y Q&A", value: 5000 },
        { id: '3', name: "Comunidad Privada", description: "Networking exclusivo y soporte", value: 1000 }
      ],
      price: 997,
      lastUpdated: new Date().toISOString()
    };
  },
  saveOffer: (data: OfferData) => {
    localStorage.setItem(STORAGE_KEYS.OFFER, JSON.stringify(data));
  },

  // Script Operations
  getScripts: (): ScriptData => {
    const data = localStorage.getItem(STORAGE_KEYS.SCRIPTS);
    return data ? JSON.parse(data) : {
      baseIdea: "",
      variations: [],
      lastUpdated: new Date().toISOString()
    };
  },
  saveScripts: (data: ScriptData) => {
    localStorage.setItem(STORAGE_KEYS.SCRIPTS, JSON.stringify(data));
  }
};
